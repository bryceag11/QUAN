# Data Set Description Language(DSDL) for DOTA_V1.0 dataset

## Data Structure
Please make sure the folder structure of prepared dataset is organized as followed:

```
<dataset_root>
├── test
│   └── images
│       ├── P0006.png
│       ├── P0009.png
│       ├── P0014.png
│       ├── P0015.png
│       ├── P0016.png
│       └── ...
├── train
│   ├── labelTxt-v1.0
│   │   ├── labelTxt
│   │   │   ├── P0000.txt
│   │   │   ├── P0001.txt
│   │   │   ├── P0002.txt
│   │   │   ├── P0005.txt
│   │   │   ├── P0008.txt
│   │   │   └── ...
│   │   └── trainset_reclabelTxt
│   │       ├── P0000.txt
│   │       ├── P0001.txt
│   │       ├── P0002.txt
│   │       ├── P0005.txt
│   │       ├── P0008.txt
│   │       └── ...
│   └── images
│       ├── P0000.png
│       ├── P0001.png
│       ├── P0002.png
│       ├── P0005.png
│       ├── P0008.png
│       └── ...
└── val
    ├── labelTxt-v1.0
    │   ├── labelTxt
    │   │   ├── P0003.txt
    │   │   ├── P0004.txt
    │   │   ├── P0007.txt
    │   │   ├── P0019.txt
    │   │   ├── P0027.txt
    │   │   └── ...
    │   └── valset_reclabelTxt
    │       ├── P0003.txt
    │       ├── P0004.txt
    │       ├── P0007.txt
    │       ├── P0019.txt
    │       ├── P0027.txt
    │       └── ...
    └── images
        ├── P0003.png
        ├── P0004.png
        ├── P0007.png
        ├── P0019.png
        ├── P0027.png
        └── ...
```

The folder structure of dsdl annotation for Rotated Object Detection is organized as followed:

```
<dsdl_root>
├── defs
│   ├── class-dom.yaml
│   ├── rotated-detection.yaml
│   └── global-info.json
├── set-test
│   ├── samples.json
│   └── test.yaml
├── set-train
│   ├── samples.json
│   └── train.yaml
├── set-val
│   ├── samples.json
│   └── val.yaml
├── README.md
└── config.py
```

## config.py
You can load your dataset from local or oss.
From local:

```
local = dict(
    type="LocalFileReader",
    working_dir="the root path of the prepared dataset",
)
```

Please change the 'working_dir' to the path of your prepared dataset where media data can be found,
for example: "<root>/dataset_name/prepared".

From oss:

```
ali_oss = dict(
    type="AliOSSFileReader",
    access_key_secret="your secret key of aliyun oss",
    endpoint="your endpoint of aliyun oss",
    access_key_id="your access key of aliyun oss",
    bucket_name="your bucket name of aliyun oss",
    working_dir="the prefix of the prepared dataset within the bucket")
```

Please change the 'access_key_secret', 'endpoint', 'access_key_id', 'bucket_name' and 'working_dir',
e.g. if the full path of your prepared dataset is "oss://bucket_name/dataset_name/prepared", then the working_dir should be "dataset_name/prepared".

## Related source:
1. Get more information about DSDL: [dsdl-docs](https://opendatalab.github.io/dsdl-docs/)
2. DSDL-SDK official repo: [dsdl-sdk](https://github.com/opendatalab/dsdl-sdk/)
3. Get more dataset: [OpenDataLab](https://opendatalab.com/)
